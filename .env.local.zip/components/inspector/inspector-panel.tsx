'use client'

import {
  IconBulb as LightbulbIcon,
  IconListCheck as ListTodo,
  IconMessage as MessageSquare,
  IconSearch as Search,
  IconX as X
} from '@tabler/icons-react'

import { Separator } from '@/components/ui/separator'
import { TooltipProvider } from '@/components/ui/tooltip'
import { TooltipButton } from '@/components/ui/tooltip-button'

import { ArtifactContent } from '@/components/artifact/artifact-content'
import { useArtifact } from '@/components/artifact/artifact-context'

export function InspectorPanel() {
  const { state, close } = useArtifact()
  const part = state.part
  if (!part) return null

  // Get the icon and title based on part type
  const getIconAndTitle = () => {
    switch (part.type) {
      case 'tool-search':
      case 'tool-askQuestion':
        const toolName = part.type.replace('tool-', '')
        return {
          icon: <Search size={18} />,
          title: toolName
        }
      case 'tool-todoWrite':
        return {
          icon: <ListTodo size={18} />,
          title: 'Todo List'
        }
      case 'reasoning':
        return {
          icon: <LightbulbIcon size={18} />,
          title: 'Thoughts'
        }
      case 'text':
        return {
          icon: <MessageSquare size={18} />,
          title: 'Text'
        }
      default:
        return {
          icon: <MessageSquare size={18} />,
          title: 'Content'
        }
    }
  }

  const { icon, title } = getIconAndTitle()

  return (
    <TooltipProvider>
      <div className="h-full flex flex-col overflow-hidden bg-muted md:px-4 md:pt-14 md:pb-4">
        <div className="flex flex-col h-full bg-background rounded-xl md:border overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2">
            <h3 className="flex items-center gap-2">
              <div className="p-2 rounded-md flex items-center gap-2">
                {icon}
              </div>
              <span className="text-sm font-medium capitalize">{title}</span>
            </h3>
            <TooltipButton
              variant="ghost"
              size="icon"
              onClick={close}
              aria-label="Close panel"
              tooltipContent="Close"
            >
              <X className="size-4" />
            </TooltipButton>
          </div>
          <Separator className="my-1 bg-border/50" />
          <div data-vaul-no-drag className="flex-1 overflow-y-auto p-4">
            <ArtifactContent part={part} />
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
